(function(){
    'use strict';
    angular.module('EProof.certificate',[]);

    angular.module('EProof.certificate').controller('CertificateCtrl', CertificateCtrl);

    CertificateCtrl.$inject = ['VehicleService','$rootScope'];
    function CertificateCtrl(VehicleService, $rootScope) {
        var vm = this;

        vm.data = {};
        
        
        $rootScope.$on('certificate-data',function(e, data){
            console.log('Data Received!');
            console.log(data);
           vm.transaction = data; 
        });
        
        

        reset();

        function reset() {
            vm.displayPOO = false;
            vm.displayCOO = false;
        }

        vm.findCertificate = function () {
            console.log(vm.code);
            VehicleService.queryTransaction(vm.code).then(
                function(response){
                    vm.transaction = response.data.transaction;
                    vm.registration = response.data.registration;
                    if(response.data.previousOwner){
                        vm.previousOwner = response.data.previousOwner;
                    }
                    console.log(response.data);

                    $rootScope.$broadcast('certificate-data',response.data.transaction);
                },
                function(e){
                    alert(e.data.error);
                }
            );
        }


    }



})();