(function(){
    angular.module('EProof.product',[])
        
        .factory('ProductService', ProductService);


    ProductService.$inject = ['CRUDService','STATE_CODE'];
    function ProductService(CRUDService, STATE_CODE){
        return{
            listProducts: listProductsImpl,
            listStateProducts: listStateProductsImpl,
            createProduct: createProductImpl,
            createStateProduct: createStateProductImpl
        };

        function listProductsImpl() {
            return CRUDService.get('/product-service/list-products');
        }

        function listStateProductsImpl(){
            return CRUDService.get('/product-service/list-state-products/'+STATE_CODE);
        }

        function createProductImpl(data) {
            return CRUDService.post('/product-service/create-product', data);
        }

        function createStateProductImpl(data) {
            return CRUDService.post('/product-service/create-state-price', data);
        }
    }
})();
