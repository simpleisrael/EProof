(function(){
    angular.module('EProof.product')
        .controller('ProductCtrl', ProductCtrl);


    ProductCtrl.$inject = ['ProductService','REST_BASE_URL'];
    function ProductCtrl(ProductService,REST_BASE_URL){
        var vm = this;

        vm.data = {};

        vm.products = [];

        init();
        
        function init(){
            ProductService.listProducts().then(
                function(response){
                    vm.products = response.data;
                },
                function(){
                    alert('Unable to list products');
                }
            )
        }

        vm.saveProduct = function () {
            ProductService.createProduct(vm.data).then(
                function(response){
                    alert('Product was successfully saved!');
                    vm.data = {};
                }
            )
        };

    }
})();
