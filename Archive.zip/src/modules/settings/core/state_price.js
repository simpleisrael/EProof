(function(){
    angular.module('EProof.product')
        .controller('StateProductCtrl', StateProductCtrl);


    StateProductCtrl.$inject = ['ProductService','STATE_CODE','REST_BASE_URL'];
    function StateProductCtrl(ProductService, STATE_CODE, REST_BASE_URL){
        var vm = this;

        var setup = JSON.parse(localStorage.getItem('setup'));

        vm.types = setup.types;
        vm.states = setup.states;
        vm.products = setup.products;
        vm.loadingStates = [];

        vm.statePrices = [];

        vm.statePricesUrl = REST_BASE_URL+'/product-service/list-state-products/'+STATE_CODE;

        initState();

        init();

        function initState() {
            var state = setup.states.find(
                function(state){
                    if(state.stateShort === STATE_CODE){
                        //console.log(state);
                        return state;
                    }
                }
            );

            vm.loadingStates.push(state);

            loadStatePrices();
        }


        function init() {
            vm.data = {offense:false};
            vm.selectedType = {};
            vm.selectedState = {};
            vm.selectedProduct = {};
        }

        vm.selectType = function () {
            vm.data.carType = vm.selectedType;
        };

        vm.selectState = function () {
            vm.data.state = vm.selectedState;
        };

        vm.selectProduct = function () {
            vm.data.productType = vm.selectedProduct;
        };

        function loadStatePrices() {
            ProductService.listStateProducts().then(
                function(response){
                    vm.stateProducts = response.data;
                }
            );
        }

        vm.saveProduct = function () {
            ProductService.createStateProduct(vm.data).then(
                function(){
                    loadStatePrices();
                    init();
                    //alert('State Price was successfully saved!');
                },
                function(e){
                    console.log(e);
                }
            );
        }



    }
})();
