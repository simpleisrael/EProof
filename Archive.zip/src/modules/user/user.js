(function(){
    angular.module('EProof.user',[]);

    angular.module('EProof.user').controller('UserCtrl', UserCtrl);
    angular.module('EProof.user').controller('RoleCtrl', RoleCtrl);
    angular.module('EProof.user').controller('PermissionCtrl', PermissionCtrl);
    angular.module('EProof.user').controller('ChangePasswordCtrl', ChangePasswordCtrl);
    angular.module('EProof.user').factory('UserService', UserService);


    UserService.$inject = ['CRUDService'];
    function UserService(CRUDService) {

        var user = JSON.parse(sessionStorage.getItem('user')),
            authenticated = false;

        //doAutoLoginImpl();

        return {
            listUsers : listUsersImpl,
            login : loginImpl,
            register : registerImpl,
            doAutoLogin : doAutoLoginImpl,
            getUser : function () {return user;},
            isAuthenticated : function () {return authenticated;},
            findUserByPhone : findUserByPhoneImpl,
            changePassword : changePasswordImpl

        };


        function listUsersImpl() {
            return CRUDService.get('/user-service/list');
        }

        function loginImpl(data) {
            return CRUDService.post('/auth-service/login', data);
        }

        function registerImpl(data) {
            return CRUDService.post('/user-service/list', data);
        }

        function doAutoLoginImpl() {
            var data = {email: 'rvec007@yahoo.com', password:'goodthing'};
            loginImpl(data).then(
                function (response) {
                    console.log(response.data);
                    user = response.data;
                    authenticated = true;
                },
                function(){
                    console.log('unable to do auto login')
                }
            )
        }

        function findUserByPhoneImpl(phone) {
            var data = {phone : phone};
            return CRUDService.post('/user-service/change-password', data);
        }

        function changePasswordImpl(data) {
            return CRUDService.post('/user-service/list', data);
        }
    }


    UserCtrl.$inject = ['$scope','UserService'];
    function UserCtrl($scope, UserService){

        $scope.msg = 'Welcome Orange Apple Technologies!';

        $scope.data = {};

        $scope.users = [];

        listUsers();

        function listUsers(){
            UserService.listUsers().then(
                function (response) {
                    console.log(response.data);
                    $scope.users = response.data;
                },
                function(){
                    alert('Network Problem \n Unable to Display available users');
                }
            )
        }

        $scope.createUser = function(){
            console.log($scope.data);
        };

    }


    ChangePasswordCtrl.$inject = ['UserService'];
    function ChangePasswordCtrl(UserService) {
        var vm = this;

        vm.data = {key:UserService.getUser().key};
        
        console.log(UserService.getUser());

        vm.changePassword = function () {
            
            console.log(vm.data);

            if(vm.confirmPassword !== vm.data.newPassword){
                alert('Your password do not match');
                return;
            }

            if(vm.data.oldPassword !== UserService.getUser().password){
                alert('Your old password is wrong');
                return;
            }

            console.log(vm.data);
        }
    }

    RoleCtrl.$inject = ['$scope'];
    function RoleCtrl($scope){

        $scope.data = {};

    }

    PermissionCtrl.$inject = ['$scope'];
    function PermissionCtrl($scope){

    }
})();
