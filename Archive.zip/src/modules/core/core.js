(function(){

    'use strict';

    angular.module('EProof.core',[]);

    angular.module('EProof.core').factory('CRUDService', CRUDService);
    angular.module('EProof.core').factory('CoreService', CoreService);
    angular.module('EProof.core').controller('MainCtrl', MainCtrl);
    angular.module('EProof.core').controller('DashboardCtrl', DashboardCtrl);

    angular.module('EProof.core').filter('epPlateNumberFilter', PlateNumberFilter);
    angular.module('EProof.core').filter('epRemoveSpaceFilter', RemoveSpaceFilter);

    CRUDService.$inject = ['REST_BASE_URL','$http'];
    function CRUDService(REST_BASE_URL,$http){
        var base_url = REST_BASE_URL;
        return{
            post: postImpl,
            get: getImpl
        };

        function postImpl(context, data){
            return $http({
                url: base_url+context,
                method: "POST",
                data: data
            });
        }

        function getImpl(context, params){
            if(!angular.isDefined(params)) params = {};
            return $http({
                url: base_url+context,
                method: "GET",
                params: params
            });
        }
    }


    CoreService.$inject = ['CRUDService'];
    function CoreService(CRUDService){

        return {
            getStates: getStatesImpl,
            getLgas: getLgasImpl
        };


        function getStatesImpl(){
            return CRUDService.get('/state-service/state/list');
        }

        function getLgasImpl(id) {
            return CRUDService.get('/state-service/city/find-by-state/'+id);
        }

    }



    MainCtrl.$inject = ['$scope'];
    function MainCtrl($scope){

        $scope.hello = 'Hello Eproof Platform';

    }



    DashboardCtrl.$inject = ['$scope'];
    function DashboardCtrl($scope){

        $scope.hello = 'Hello Eproof Platform';

    }
    
    
    PlateNumberFilter.$inject = [];
    function PlateNumberFilter() {
        
        return function (plateNumber) {
            if(!angular.isDefined(plateNumber))return '';

            var split = plateNumber.split(' ');
            var word = '';

            angular.forEach(split, function(splitWord){
                word+=splitWord;
            });

            console.log(word);

            if(word.length === 8){
                var w1, w2, w3;
                w1 = word.substring(0,3);
                w2 = word.substring(3,6);
                w3 = word.substring(6,8);

                return w1+' '+w2+' '+w3;
            }else{
                return word;
            }
        }

    }
    
    
    RemoveSpaceFilter.$inject = [];
    function RemoveSpaceFilter() {
        return function(plateNumber){
            if(!angular.isDefined(plateNumber))return '';

            var split = plateNumber.split(' ');
            var word = '';

            angular.forEach(split, function(splitWord){
                word+=splitWord;
            });

            return word;
        }
    }
    
    


})();
