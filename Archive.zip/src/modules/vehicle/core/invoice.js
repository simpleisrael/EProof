(function(){
    angular.module('EProof.vehicle').controller('InvoiceCtrl', InvoiceCtrl);

    InvoiceCtrl.$inject = ['$routeParams','VehicleService'];
    function InvoiceCtrl($routeParams, VehicleService){
        var vm = this;

        var code = $routeParams.code;

        vm.registrationDetails = {};

        vm.display = false;

        queryTransaction();

        function queryTransaction(){
            VehicleService.queryTransaction(code).then(
                function(response){
                    vm.registrationDetails = response.data.registration;
                    vm.transactionDetails = response.data.transaction;
                    vm.display = true;
                    console.log(response.data);
                },
                function (e) {
                    console.log(e);
                }
            )
        }
    }
})();
