(function(){
    angular.module('EProof.vehicle').controller('RoadWorthinessCtrl', RoadWorthinessCtrl);

    RoadWorthinessCtrl.$inject = ['VehicleService'];
    function RoadWorthinessCtrl(VehicleService){
        var vm = this;


    }
})();
