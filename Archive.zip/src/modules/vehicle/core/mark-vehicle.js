(function(){
    angular.module('EProof.vehicle').controller('MarkCtrl', MarkCtrl);

    MarkCtrl.$inject = ['VehicleService','UserService','$location'];
    function MarkCtrl(VehicleService, UserService, $location){

        var vm =this;

        vm.data = {
            userId:vm.user
        };

        var setup = JSON.parse(localStorage.getItem('setup'));

        console.log(setup);

        var PRODUCT_CODE = 'EP001';//THIS is the code for EProof Vehicle Registration. It has been configured with the system and hence, ***DO NOT EDIT***

        vm.data.productStatePrice = setup.statePrices.find(
            function(stateP){
                if(stateP.productTypeId.code === PRODUCT_CODE){
                    return stateP;
                }
            }
        );

        vm.user = JSON.parse(sessionStorage.getItem('user'));

        vm.titles = ['Mr','Mrs','Miss','Master','Dr','Chief','Engr'];

        vm.plateChecked = true;
        vm.vehicleVerified = false;
        vm.ownerChecked = false;
        vm.confirmed = false;
        vm.registered = false;

        vm.plateNumberDuplicate = false;
        vm.engineNumberDuplicate = false;
        vm.chassisNumberDuplicate = false;

        vm.car = {};

        vm.states = [];

        vm.lgas = [];

        vm.data.ownerId = {telephone:''};

        init();

        vm.registrationDetails = {};


        vm.checkVehicle = function () {
            VehicleService.findVehicle(vm.data.plateNumber).then(
                function(response){
                    vm.data = response.data;//Initialize the car object
                    vm.plateChecked = true;
                },
                function (e) {
                    console.log(e);
                    vm.plateChecked = true;
                }
            )
        };

        vm.checkPlateNumberDuplicate = function () {
            vm.plateNumberDuplicate = false;

            VehicleService.findVehicle(vm.data.plateNumber).then(
                function(response){
                    console.log(response.data);
                    vm.plateNumberDuplicate = true;
                },
                function(e){
                    console.log(e);
                }
            )
        };


        vm.checkEngineDuplicate = function () {
            vm.engineNumberDuplicate = false;

            VehicleService.findVehicleByEngine(vm.data.engine).then(
                function(response){
                    console.log(response.data);
                    vm.engineNumberDuplicate = true;
                },
                function(e){
                    console.log(e);
                }
            )
        };


        vm.checkChassisDuplicate = function () {
            vm.chassisNumberDuplicate = false;

            VehicleService.findVehicleByChassis(vm.data.chassis).then(
                function(response){
                    console.log(response.data);
                    vm.chassisNumberDuplicate = true;
                },
                function(e){
                    console.log(e);
                }
            )
        };

        vm.checkOwner = function () {

            if(!vm.data.ownerId.telephone || vm.data.ownerId.telephone.length === 0){
                alert('Invalid Phone Number');
                return;
            }

            VehicleService.findOwner(vm.data.ownerId.telephone).then(
                function(response){
                    vm.data.ownerId = response.data;//Initialize the owner object
                    vm.selectedTitle = response.data.title;

                    vm.ownerChecked = true;
                },
                function (e) {
                    console.log(e);
                    vm.ownerChecked = true;
                }
            )
        };

        vm.verifyVehicleDetails = function () {

            initProductStatePrice(vm.data.stateId.stateShort);

        };

        vm.back2 = function () {
            vm.confirmed = false;
        };

        vm.back1 = function () {
            vm.vehicleVerified = false;
        };

        vm.confirmRegistration = function () {
            vm.confirmed = true;
        };

        vm.markVehicle = function () {
            vm.data.userId = UserService.getUser();
            VehicleService.markVehicle(vm.data).then(
                function (response) {
                    vm.registrationDetails = response.data;
                    vm.registered = true;
                    console.log('Registration Successful!');
                    $location.path('/vehicle/invoice/'+response.data.code);
                },
                function(e){
                    console.log(e);
                }
            )
        };

        function init(){
            vm.purposes = setup.purposes;
            vm.brands = setup.brands;
            vm.colors = setup.colors;
            vm.states = setup.states;
            vm.types = setup.types;
            vm.loadingStates = [];
            vm.loadingStates.push(vm.user.stateId);

            initYear();
        }

        function initYear(){
            VehicleService.getVehicleYears().then(
                function (response) {
                    vm.years = response;
                }
            )
        }

        function initProductStatePrice(){
            //Enable the confirmed vehicle verified
            vm.vehicleVerified = true;
        }


        function loadLga(code) {
            vm.lgas = setup.lgas.filter(
                function(lga){
                    if(lga.stateId.stateShort === code){
                        return lga;
                    }
                }
            );
        }


        vm.selectState = function () {
            vm.data.stateId = vm.selectedState;
        };
        vm.selectOwnerState = function () {
            vm.data.ownerId.state = vm.selectedOwnerState;
            loadLga(vm.selectedOwnerState.stateShort);
        };
        vm.selectStateSpec = function () {
            vm.data.spec = 'VIN'+vm.selectedStateSpec.stateShort;
        };
        vm.selectPurpose = function () {
            vm.data.purposeId = vm.selectedPurpose;
        };
        vm.selectColor = function () {
            vm.data.colorId = vm.selectedColor;
        };
        vm.selectBrand = function () {
            vm.data.makeId = vm.selectedBrand;
        };
        vm.selectType = function () {
            vm.data.typeId = vm.selectedType;
        };
        vm.selectTitle = function () {
            vm.data.ownerId.title = vm.selectedTitle;
        };
        vm.selectYear = function () {
            vm.data.carYear = vm.selectedYear;
        };
        vm.selectOwnerLga = function(){
            vm.data.ownerId.lga = vm.selectedOwnerLga.areaName;
        }
    }
})();
