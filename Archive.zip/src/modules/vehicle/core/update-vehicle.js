(function(){
    angular.module('EProof.vehicle').controller('UpdateCtrl', UpdateCtrl);

    UpdateCtrl.$inject = ['VehicleService'];
    function UpdateCtrl(VehicleService){
        var vm = this;



    }
})();
