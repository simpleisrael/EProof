(function(){
    angular.module('EProof.vehicle').controller('VehicleSwapCtrl', VehicleSwapCtrl);

    VehicleSwapCtrl.$inject = ['$scope','VehicleService','UserService','CoreService','$location'];
    function VehicleSwapCtrl($scope, VehicleService, UserService, CoreService, $location) {

        var vm =this;

        var setup = JSON.parse(localStorage.getItem('setup'));

        vm.data = {
            userId:vm.user
        };

        console.log(setup);

        var PRODUCT_CODE = 'EP002';//THIS is the code for EProof Vehicle Registration. It has been configured with the system and hence, ***DO NOT EDIT***

        vm.data.productStatePrice = setup.statePrices.find(
            function(price){
                if(price.productTypeId.code === PRODUCT_CODE){
                    return price;
                }
            }
        );

        console.log('State Price');
        console.log(vm.data.productStatePrice);

        vm.user = JSON.parse(sessionStorage.getItem('user'));

        vm.titles = ['Mr','Mrs','Miss','Master','Dr','Chief','Engr'];

        vm.plateChecked = true;
        vm.vehicleVerified = false;
        vm.newOwnerVerified = false;
        vm.ownerChecked = false;
        vm.confirmed = false;
        vm.registered = false;
        
        vm.vehicleExist = false;

        vm.car = {};

        vm.states = [];

        vm.lgas = [];

        vm.data.ownerId = {telephone:''};
        vm.data.previousOwnerId = {telephone:''};

        init();


        vm.registrationDetails = {};

        vm.checkVehicle = function () {
            VehicleService.findVehicle(vm.data.plateNumber).then(
                function(response){
                    vm.data = response.data;//Initialize the car object
                    vm.plateChecked = true;
                },
                function (e) {
                    console.log(e);
                    vm.plateChecked = true;
                }
            )
        };

        vm.checkOwner = function () {

            if(!vm.data.ownerId.telephone || vm.data.ownerId.telephone.length === 0){
                alert('Invalid Phone Number');
                return;
            }

            VehicleService.findOwner(vm.data.ownerId.telephone).then(
                function(response){
                    vm.data.ownerId = response.data;//Initialize the owner object
                    vm.selectedTitle = response.data.title;

                    vm.ownerChecked = true;
                },
                function (e) {
                    console.log(e);
                    vm.ownerChecked = true;
                }
            )
        };

        
        vm.checkVehicleExist = function () {
            vm.vehicleExist = false;
            VehicleService.findVehicle(vm.data.plateNumber).then(
                function(response){
                    vm.vehicleExist = true;
                    console.log(response.data);
                    initVehicleData(response.data);
                },
                function(e){
                    vm.vehicleExist = false;
                    vm.data = {};
                }
            )
        };

        vm.verifyVehicleDetails = function () {

            initProductStatePrice(vm.data.stateId.stateShort);

        };

        vm.back2 = function () {
            vm.confirmed = false;
        };

        vm.back1 = function () {
            vm.vehicleVerified = false;
        };


        vm.continueRegistration = function () {
            vm.newOwnerVerified = true;
        };


        vm.confirmRegistration = function () {
            vm.confirmed = true;
        };

        vm.registerVehicle = function () {
            vm.data.userId = UserService.getUser();
            showBlock();
            VehicleService.swapVehicle(vm.data).then(
                function (response) {
                    vm.registrationDetails = response.data;
                    vm.registered = true;
                    hideBlock();
                    console.log('Registration Successful!');
                    $location.path('/vehicle/invoice/'+response.data.code);
                },
                function(e){
                    hideBlock();
                    console.log(e);
                }
            )
        };

        function init(){
            vm.purposes = setup.purposes;
            vm.brands = setup.brands;
            vm.colors = setup.colors;
            vm.states = setup.states;
            vm.types = setup.types;
            vm.loadingStates = [];
            vm.loadingStates.push(vm.user.stateId);
            console.log(vm.loadingStates);

            initYear();
        }

        function initYear(){
            VehicleService.getVehicleYears().then(
                function (response) {
                    vm.years = response;
                }
            )
        }

        function initProductStatePrice(){
            //Enable the confirmed vehicle verified
            vm.vehicleVerified = true;
        }

        function loadLga(code) {
            vm.lgas = setup.lgas.filter(
                function(lga){
                    if(lga.stateId.stateShort === code){
                        return lga;
                    }
                }
            );
        }

        vm.selectState = function () {
            vm.data.stateId = vm.selectedState;
        };

        vm.selectOwnerState = function () {
            vm.data.ownerId.state = vm.selectedOwnerState;
            loadLga(vm.selectedOwnerState.stateShort);
        };
        vm.p_selectOwnerState = function () {
            vm.data.previousOwnerId.state = vm.p_selectedOwnerState;
            loadLga(vm.p_selectedOwnerState.stateShort);
        };

        vm.selectTitle = function () {
            vm.data.ownerId.title = vm.selectedTitle;
        };
        vm.p_selectTitle = function () {
            vm.data.previousOwnerId.title = vm.selectedTitle;
        };

        vm.selectStateSpec = function () {
            vm.data.spec = 'VIN'+vm.selectedStateSpec.stateShort;
        };
        vm.selectPurpose = function () {
            vm.data.purposeId = vm.selectedPurpose;
        };
        vm.selectColor = function () {
            vm.data.colorId = vm.selectedColor;
        };
        vm.selectBrand = function () {
            vm.data.makeId = vm.selectedBrand;
        };
        vm.selectType = function () {
            vm.data.typeId = vm.selectedType;
        };
        vm.selectYear = function () {
            vm.data.carYear = vm.selectedYear;
        };
        vm.selectOwnerLga = function(){
            vm.data.ownerId.lga = vm.selectedOwnerLga.areaName;
        };
        vm.p_selectOwnerLga = function(){
            vm.data.previousOwnerId.lga = vm.p_selectedOwnerLga.areaName;
        };


        function initVehicleData(data){
            vm.data.stateId = data.state;
            vm.data.spec = data.spec;
            vm.data.purposeId = data.purpose;
            vm.data.colorId = data.color;
            vm.data.makeId = data.make;
            vm.data.engine = data.engine;
            vm.data.chassis = data.chasis;
            vm.data.carYear = data.carYear;
            vm.data.model = data.model;
            vm.data.previousOwnerId = data.owner;
            vm.data.typeId = data.type;
            vm.data.plateNumber = data.plateNumber;

            vm.selectedState = data.state;
            vm.selectedBrand = data.make;
            vm.selectedColor = data.color;
            vm.selectedType = data.type;
            vm.selectedPurpose = data.purpose;
        }


    }

})();
    