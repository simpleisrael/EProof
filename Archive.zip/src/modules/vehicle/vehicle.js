(function(){
    'use strict';
    angular.module('EProof.vehicle',[]);
    
    angular.module('EProof.vehicle').factory('VehicleService', VehicleService);
    
    VehicleService.$inject = ['CRUDService', '$q'];
    function VehicleService(CRUDService, $q) {
        return{
            findVehicle: findVehicleImpl,
            findVehicleByChassis: findVehicleByChassisImpl,
            findVehicleByEngine: findVehicleByEngineImpl,
            getVehicleBrands: getVehicleMakeImpl,
            getVehicleYears: getVehicleYearImpl,
            getVehicleColors: getVehicleColorImpl,
            getVehiclePurposes: getVehiclePurposeImpl,
            getVehicleTypes: getVehicleTypesImpl,
            findOwner: findOwnerImpl,
            loadProductDetails: loadProductDetailsImpl,
            registerVehicle : registerVehicleImpl,
            markVehicle : markVehicleImpl,
            swapVehicle : swapVehicleImpl,
            queryTransaction: queryTransactionImpl, 
            queryNIBBSTransaction: queryNIBBSTransactionImpl
        };


        function findVehicleImpl(plateNumber) {
            var data = {plateNumber : plateNumber};
            return CRUDService.post('/vehicle-service/find-vehicle', data);
        }

        function findVehicleByEngineImpl(engine) {
            var data = {engine : engine};
            return CRUDService.post('/vehicle-service/find-vehicle-engine', data);
        }

        function findVehicleByChassisImpl(chassis) {
            var data = {chassis : chassis};
            return CRUDService.post('/vehicle-service/find-vehicle-chassis', data);
        }

        function getVehicleMakeImpl(){
            return CRUDService.get('/vehicle-service/list-brands');
        }

        function getVehicleYearImpl(){
            var result = [
                '1980','1981','1982','1983','1984','1985','1986','1987','1988','1989','1990',
                '1991','1992','1993','19994','1995','1996','1997','1998','1999','2000','2001',
                '2002','2003','2004','2005','2006','2007','2008','2009','2010','2011','2012',
                '2013','2014','2015','2016','2017'
            ];
            
            var defer = $q.defer();
            
            defer.resolve(result);
            
            return defer.promise;
            
            
        }

        function getVehicleColorImpl(){
            return CRUDService.get('/vehicle-service/list-colors');
        }

        function getVehiclePurposeImpl(){
            return CRUDService.get('/vehicle-service/list-purposes');
        }

        function getVehicleTypesImpl() {
            return CRUDService.get('/vehicle-service/list-types');
        }

        function findOwnerImpl(phone) {
            var data = {telephone: phone};
            return CRUDService.post('/vehicle-service/find-owner', data);
        }

        function loadProductDetailsImpl(typeCode, stateCode) {
            var data = {typeCode: typeCode, stateCode: stateCode};
            return CRUDService.post('/product-service/find-state-price', data);
        }

        function registerVehicleImpl(data) {
            return CRUDService.post('/vehicle-service/save-vehicle', data);
        }

        function markVehicleImpl(data) {
            return CRUDService.post('/vehicle-service/mark-vehicle', data);
        }

        function swapVehicleImpl(data) {
            return CRUDService.post('/vehicle-service/swap-vehicle', data);
        }

        function queryTransactionImpl(code){
            var data = {code: code};
            return CRUDService.post('/nibbs-transaction-service/query-default-transaction', data);
        }

        function queryNIBBSTransactionImpl(code){
            var data = {code: code};
            return CRUDService.post('/nibbs-transaction-service/query-transaction', data);
        }

    }
    
})();