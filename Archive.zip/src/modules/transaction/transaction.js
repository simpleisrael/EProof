(function(){
    'use strict';
    angular.module('EProof.transaction',[]);

    angular.module('EProof.transaction').controller('TransactionCtrl', TransactionCtrl);
    angular.module('EProof.transaction').controller('QueryTransactionCtrl', QueryTransactionCtrl);
    
    TransactionCtrl.$inject = [];
    function TransactionCtrl() {
        var vm = this;
    }


    QueryTransactionCtrl.$inject = ['VehicleService'];
    function QueryTransactionCtrl(VehicleService){
        var vm = this;

        vm.code = '';

        vm.registrationDetails = {};

        vm.display = false;

        vm.transactionDetails = {};

        vm.queryTransaction = function(){
            vm.display = false;
            showBlock();
            VehicleService.queryNIBBSTransaction(vm.code).then(
                function(response){
                    vm.transactionDetails = response.data;
                    vm.display = true;
                    console.log(response.data);
                    hideBlock();
                },
                function (e) {
                    console.log(e);
                    hideBlock();
                }
            )
        }
    }


})();