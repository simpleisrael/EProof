(function(){
    angular.module('EProof.ticketing',[]);
    angular.module('EProof.ticketing').factory('TicketService', TicketService);
    angular.module('EProof.ticketing').controller('OTramTicketCtrl', OTramTicketCtrl);
    angular.module('EProof.ticketing').controller('FindTicketCtrl', FindTicketCtrl);
    angular.module('EProof.ticketing').controller('ListTicketCtrl', ListTicketCtrl);


    TicketService.$inject = ['CRUDService'];
    function TicketService(CRUDService) {
        return {
            getStatePrices: getStatePriceImpl,
            generateTicket: generateTicketImpl,
            findTicket: findTicketImpl,
            listTicket: listTicketImpl
        };
        
        function getStatePriceImpl(){
            var setup = JSON.parse(localStorage.getItem('setup'));
            return setup.statePrices;
        }
        
        function generateTicketImpl(data) {
            return CRUDService.post('/vehicle-service/generate-ticket', data);
        }
        
        function findTicketImpl(num){
            var data = {number:num};
            return CRUDService.post('/vehicle-service/find-ticket', data);
        }
        
        function listTicketImpl(start, limit) {
            var data = {start:start, limit:limit};
            return CRUDService.post('/vehicle-service/list-ticket', data);
        }
    }


    OTramTicketCtrl.$inject = ['TicketService','VehicleService','UserService','$location'];
    function OTramTicketCtrl(TicketService, VehicleService, UserService, $location){
        var vm = this;

        var PRODUCT_CODE = 'EP006';//THIS is the code for EProof Vehicle Registration. It has been configured with the system and hence, ***DO NOT EDIT***

        vm.data = {};
        
        vm.inputData = {};
        
        vm.checkingVehicle = false;
        vm.checkedVehicle = false;
        
        vm.demo = ['1','2','3','4','5','6','7','8','9'];
        
        vm.vehicleTypes = ['Motorcycle','Saloon Car'];
        
        vm.vehicleError = false;
        vm.errorMessage = '';
        
        vm.vehicleConfirmed = false;
        
        vm.ticketSelected = false;
        
        vm.car = {};
        
        vm.selectedType = {};
        vm.selectedVehicleType = '';

        vm.ticketTypes = [{name:'OTram',code:'EP006'},{name:'VIO',code:'EP007'}];

        vm.vehicleTypes = ['Salon Car','Motorcycle'];
        
        vm.offenseList = [];


        initStatePrices();
        
        //console.log(vm.inputData.statePrices);
        
        vm.checkVehicle = function () {
            vm.data.plateNumber = vm.data.plateNumber.split(" ").join('');
            
            vm.checkingVehicle = true;
            
            VehicleService.findVehicle(vm.data.plateNumber).then(
                function(response){
                    vm.car = response.data;
                    
                    vm.checkedVehicle = true;
                    vm.checkingVehicle = false;
                    vm.vehicleError = false;
                    
                    //console.log(response.data);
                },
                function(e){
                    vm.errorMessage = e.data.error;

                    vm.vehicleError = true;
                    vm.checkingVehicle = false;
                }
            );
        };

        vm.confirmVehicle = function () {
            vm.vehicleConfirmed = true;
        };
        
        vm.back = function () {
            vm.checkedVehicle = false;
            vm.vehicleConfirmed = false;
            clearOffenseList();
        };
        
        function clearOffenseList() {
            vm.offenseList = [];
            vm.inputData.statePrices.forEach(function (csp, index) {
                if (csp.checked) {
                    csp.checked = false;
                }
            });
        }
        
        vm.selectType = function () {
            PRODUCT_CODE = vm.selectedType.code;
            initStatePrices();
            //console.log(vm.selectedType);
        };

        vm.selectVehicleType = function () {
            clearOffenseList();
            vm.inputData.statePrices = TicketService.getStatePrices().filter(
                function(sp){
                    if(sp.carType.typeName === vm.selectedVehicleType && sp.productTypeId.code === PRODUCT_CODE){
                        return sp;
                    }
                }
            );
        };

        
        vm.addOffense = function (sp) {
            if(sp.checked){
                vm.offenseList.push(sp);
            }else {
                vm.offenseList.forEach(function (csp, index) {
                    if (sp.id === csp.id) {
                        vm.offenseList.splice(index, 1);
                        //console.log(vm.offenseList);
                    }
                });
            }
        };
        //console.log(vm.data.statePrices);


        vm.confirmTicketRegistration = function () {
            vm.data.plateNumber = vm.car.plateNumber;
            vm.data.userId = UserService.getUser().id;
            vm.data.offenses = [];
            vm.offenseList.forEach(function(offense){
                vm.data.offenses.push(offense.id);
            });
            
            var confirmed = confirm("Are you sure you want to generate this ticket?");
            
            if(!confirmed){
                return;
            }

            showBlock();
            TicketService.generateTicket(vm.data).then(
                function(response){
                    hideBlock();
                    $location.path('/vehicle/invoice/'+response.data.code);
                },
                function(e){
                    alert(e.data.error);
                    hideBlock();
                }
            );
            
            //console.log(vm.data);
        };


        function initStatePrices(){
            vm.inputData.statePrices = TicketService.getStatePrices().filter(
                function(sp){
                    if(sp.productTypeId.code === PRODUCT_CODE){
                        return sp;
                    }
                }
            );
        }


        function filterStatePricesByCarType(carType){
            vm.inputData.statePrices = TicketService.getStatePrices().filter(
                function(sp){
                    if(sp.productTypeId.code === PRODUCT_CODE && sp.carType.typeName === 'carType'){
                        return sp;
                    }
                }
            );
        }
        
    }
    
    
    


    FindTicketCtrl.$inject = ['TicketService'];
    function FindTicketCtrl(TicketService){
        var vm = this;
        
        vm.data = {};
        
        vm.ticket = {};
        
        vm.ticketFound = false;

        vm.findingTicket = false;
        
        vm.findTicket = function() {
            vm.ticketFound = false;
            vm.findingTicket = true;
            showBlock();
            TicketService.findTicket(vm.data.number).then(
                function (response) {
                    vm.ticket = response.data.ticket;
                    vm.transaction = response.data.transaction;
                    vm.ticketFound = true;
                    vm.findingTicket = false;
                    hideBlock();
                },
                function(e){
                    alert(e.data.error);
                    vm.ticketFound = false;
                    vm.findingTicket = false;
                    hideBlock();

                }
            )
        };
        
        
        vm.next = function () {
            start++;
        }
    }
    
    


    ListTicketCtrl.$inject = ['TicketService'];
    function ListTicketCtrl(TicketService){
        var vm = this;

        vm.data = {};
        
        vm.tickets = [];
        
        vm.findingTicket = false;

        var start = 0;
        var limit = 100;
        
        vm.listRecentTickets = function(){
            listTickets(10);
        };
        
        vm.listTickets = function () {
            listTickets();
        };


        function listTickets(limitInput) {
            var lim = limitInput || limit;
            showBlock();
            vm.findingTicket = true;
            TicketService.listTicket(start, lim).then(
                function (response) {
                    vm.tickets = response.data;
                    vm.findingTicket = false;
                    hideBlock();
                    console.log(vm.tickets);
                },
                function(e){
                    alert(e.data.error);
                    vm.findingTicket = false;
                    hideBlock();
                }
            )
        }


        
        
        vm.next = function () {
            start++;
        }
    }
})();

