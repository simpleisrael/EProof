(function(){
    angular.module('EProof', ['EProof.core','EProof.user','EProof.vehicle',
        'EProof.product','EProof.transaction','EProof.ticketing','EProof.certificate',
        'ngRoute','objectTable','monospaced.qrcode'])

        .constant('REST_BASE_URL', 'http://127.0.0.1:8080')
        //.constant('REST_BASE_URL', 'http://127.0.0.1:8080/eproof')
        .constant('STATE_CODE', sessionStorage.getItem('STATE_CODE'))
        .constant('FINES_PRODUCT_CODES',[])
        .constant('STATE', 'OSUN')

        .run(function(){
            var user = sessionStorage.getItem('user');

            if(user===null){
                location.pathname = '/auth.html';
            }else{
                console.log('User already authenticated...');
                
                //Initialize Default global functions
                window.showBlock = function(message){
                    var msg = message || 'Please Wait...';

                    $.blockUI({
                        message: '<h5 style="text-align:center;">' +
                        '<img src="../assets/img/loading.gif" />' +
                        '<span style="display:block ">'+msg+'</span> </h5>',
                        css: {
                            border: 'none',
                            padding: '15px',
                            backgroundColor: 'transparent',
                            '-webkit-border-radius': '10px',
                            '-moz-border-radius': '10px',
                            opacity: 1
                        },

                        overlayCSS:  {
                            backgroundColor: 'transparent',
                            opacity: 1,
                            cursor: 'wait'
                        }
                    });
                };


                window.hideBlock = function(){
                    $.unblockUI();
                }
            }
        })


        .config(['$routeProvider', '$locationProvider', function($routeProvider, $locationProvider) {

            $routeProvider.when('/dashboard', {templateUrl:'/src/partials/dashboard.html', controller: 'DashboardCtrl'});

            $routeProvider.when('/profile/user/create', {templateUrl:'/src/partials/profile/user/create.html', controller: 'UserCtrl'});
            $routeProvider.when('/profile/user/list', {templateUrl:'/src/partials/profile/user/list.html', controller: 'UserCtrl'});
            $routeProvider.when('/profile/user/change-password', {templateUrl:'/src/partials/profile/user/change-password.html', controller: 'ChangePasswordCtrl', controllerAs: 'vm'});

            $routeProvider.when('/profile/roles', {templateUrl:'/src/partials/profile/role/role.html', controller: 'RoleCtrl'});

            $routeProvider.when('/profile/permissions', {templateUrl:'/src/partials/profile/permission/permission.html', controller: 'PermissionCtrl'});

            $routeProvider.when('/vehicle/register', {templateUrl:'/src/partials/vehicle/register.html', controller: 'VehicleRegistrationCtrl', controllerAs: 'vm'});
            $routeProvider.when('/vehicle/swap', {templateUrl:'/src/partials/vehicle/swap.html', controller: 'VehicleSwapCtrl', controllerAs: 'vm'});
            $routeProvider.when('/vehicle/mark', {templateUrl:'/src/partials/vehicle/mark.html', controller: 'MarkCtrl', controllerAs: 'vm'});
            $routeProvider.when('/vehicle/update', {templateUrl:'/src/partials/vehicle/update.html', controller: 'UpdateCtrl', controllerAs: 'vm'});
            $routeProvider.when('/vehicle/road-worthiness', {templateUrl:'/src/partials/vehicle/road-worthiness.html', controller: 'RoadWorthinessCtrl', controllerAs: 'vm'});
            $routeProvider.when('/vehicle/invoice/:code', {templateUrl:'/src/partials/vehicle/invoice.html', controller: 'InvoiceCtrl', controllerAs: 'vm'});

            $routeProvider.when('/ticketing/new-ticket', {templateUrl:'/src/partials/ticketing/new-ticket.html', controller: 'OTramTicketCtrl', controllerAs: 'vm'});
            $routeProvider.when('/ticketing/view', {templateUrl:'/src/partials/ticketing/view.html', controller: 'ListTicketCtrl', controllerAs: 'vm'});
            $routeProvider.when('/ticketing/find-ticket', {templateUrl:'/src/partials/ticketing/find-ticket.html', controller: 'FindTicketCtrl', controllerAs: 'vm'});
            
            $routeProvider.when('/certificate', {templateUrl:'/src/partials/certificate/certificate.html', controller: 'CertificateCtrl', controllerAs: 'vm'});

            $routeProvider.when('/transaction/view', {templateUrl:'/src/partials/transaction/view.html', controller: 'TransactionCtrl', controllerAs: 'vm'});
            $routeProvider.when('/transaction/query', {templateUrl:'/src/partials/transaction/query.html', controller: 'QueryTransactionCtrl', controllerAs: 'vm'});

            $routeProvider.when('/setting/products', {templateUrl:'/src/partials/setting/products.html', controller: 'ProductCtrl', controllerAs: 'vm'});
            $routeProvider.when('/setting/state-products', {templateUrl:'/src/partials/setting/state-products.html', controller: 'StateProductCtrl', controllerAs: 'vm'});
            $routeProvider.when('/setting/configure', {templateUrl:'/src/partials/setting/configure-attributes.html', controller: 'ProductCtrl', controllerAs: 'vm'});

            $routeProvider.otherwise({redirectTo: '/dashboard'});

            //$locationProvider.html5Mode(true);
        }]);
})();
