function getLocalValue(key){
    return localStorage.getItem(key);
}

function setLocalValue(key, value) {
    localStorage.setItem(key, value);
}

function getSessionValue(key) {
    return sessionStorage.getItem(key);
}

function setSessionValue(key, value) {
    sessionStorage.setItem(key, value);
}

function initProductTypes($http){

}