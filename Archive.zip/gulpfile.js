var gulp = require('gulp');
var uglify = require('gulp-uglify');
var concat = require('gulp-concat');
var jshint = require('gulp-jshint');
var sass = require('gulp-sass');
var livereload = require('gulp-livereload');
var gzip = require('gulp-gzip');
var cssmin = require('gulp-cssmin');
var htmlmin = require('gulp-htmlmin');
var copy = require('gulp-contrib-copy');

gulp.task('app', function() {
    gulp.src(['src/**/*.js'])
        .pipe(concat('app-v0.1.min.js'))
        .pipe(uglify({compress:true, mangle:true}))
        .pipe(jshint())
        .pipe(gulp.dest('./dist/js/'))
});

gulp.task('core-lib', function() {
    gulp.src([
        'libs/bower/jquery/dist/jquery.js',
        'bower_components/angular/angular.js',
        'bower_components/angular-route/angular-route.min.js',
        'libs/bower/jquery-ui/jquery-ui.min.js',
        'libs/bower/jQuery-Storage-API/jquery.storageapi.min.js',
        'libs/bower/bootstrap-sass/assets/javascripts/bootstrap.js',
        'libs/bower/superfish/dist/js/hoverIntent.js',
        'libs/bower/superfish/dist/js/superfish.js',
        'libs/bower/jquery-slimscroll/jquery.slimscroll.js',
        'libs/bower/perfect-scrollbar/js/perfect-scrollbar.jquery.js',
        'libs/bower/PACE/pace.min.js',
        'libs/bower/selectordie/selectordie.min.js',
        'libs/bower/object-table/object-table.js',
        'bower_components/qrcode-generator/js/qrcode.js',
        'bower_components/angular-qrcode/angular-qrcode.js',
        'libs/bower/Print.js/dist/print.min.js',
        'bower_components/moment/min/moment.min.js',
        'libs/bower/block-ui/jquery.blockUI.js'
    ])
        .pipe(concat('core-bundle.js'))
        .pipe(uglify({mangle:true, compress:true}))
        .pipe(jshint())
        .pipe(gulp.dest('./dist/js/'))
});

gulp.task('app-lib', function() {
    gulp.src([
        'assets/js/library.js',
        'assets/js/plugins.js',
        'assets/js/app.js',
        'libs/bower/moment/moment.js',
        'libs/bower/fullcalendar/dist/fullcalendar.min.js',
        'assets/js/fullcalendar.js'
    ])
        .pipe(concat('main-bundle.js'))
        .pipe(uglify({mangle:true, compress:true}))
        .pipe(jshint())
        .pipe(gulp.dest('./dist/js/'))
});


gulp.task('css-bundle', function() {
    gulp.src([
        'libs/bower/pe/css/pe-icon.css',
        'libs/bower/animate.css/animate.min.css',
        'libs/bower/Print.js/dist/print.min.css',
        'libs/bower/fullcalendar/dist/fullcalendar.min.css',
        'libs/bower/perfect-scrollbar/css/perfect-scrollbar.css',
        'libs/bower/selectordie/selectordie.css',
        'assets/css/bootstrap.css',
        'assets/css/app.css'
    ])
        .pipe(concat('lib.v1.min.css'))
        .pipe(cssmin())
        .pipe(gzip())
        .pipe(gulp.dest('./dist/css/'))
});

/**
gulp.task('css-bundle', function() {
    gulp.src([
        'libs/bower/font-awesome/css/font-awesome.min.css',
        'libs/bower/material-design-iconic-font/dist/css/material-design-iconic-font.css',
        'libs/bower/pe/css/pe-icon.css',
        'libs/bower/animate.css/animate.min.css',
        'libs/bower/fullcalendar/dist/fullcalendar.min.css',
        'libs/bower/perfect-scrollbar/css/perfect-scrollbar.css',
        'libs/bower/selectordie/selectordie.css',
        'assets/css/bootstrap.css',
        'assets/css/app.css'
    ])
    .pipe(concat('lib.v1.min.css'))
    .pipe(cssmin())
    .pipe(gulp.dest('./dist/css/'))
});
*/


gulp.task('sass-bundle', function() {
    gulp.src('assets/sass/**/*.scss')
        .pipe(concat('app.v0.0.1.min.css'))
        .pipe(sass().on('error', sass.logError))
        .pipe(gulp.dest('./dist/css/'));
});


gulp.task('minify-main-html', function() {
    return gulp.src(['index.html','auth.html'])
        .pipe(htmlmin({
            collapseWhitespace: true,
            caseSensitive:true,
            minifyCSS:true,
            minifyJS:true,
            removeComments:true
        }))
        .pipe(gulp.dest('dist/src'));
});


gulp.task('minify-partials-html', function() {
    return gulp.src(['src/partials/**/*.html'])
        .pipe(htmlmin({
            collapseWhitespace: true,
            caseSensitive:true,
            minifyCSS:true,
            minifyJS:true,
            removeComments:true
        }))
        .pipe(gulp.dest('dist/src/partials'));
});

gulp.task('minify-html',['minify-main-html','minify-partials-html']);


gulp.task('copy', function() {
    gulp.src([
        'src/**/*',
        'index.html',
        'auth.html',
        'dist/**/*',
        'assets/**/*'
    ])
        .pipe(copy())
        .pipe(gulp.dest('deploy/'));
});


gulp.task('default', ['app','core-lib','app-lib','sass-bundle','css-bundle'], function(){
    //livereload.listen({start:true});
    //gulp.watch('src/**/*', ['app']);
});


gulp.task('all', ['default'], function(){
    gulp.src(['dist/js/core-bundle.js','dist/js/main-bundle.js','dist/js/app-v0.1.min.js'])
        .pipe(uglify({mangle:true, compress:true}))
        .pipe(jshint())
        .pipe(concat('eproof-bundle.0.0.1.min.js'))
        .pipe(gzip())
        .pipe(gulp.dest('./dist/js/'))
});


gulp.task('build-app',['app']);